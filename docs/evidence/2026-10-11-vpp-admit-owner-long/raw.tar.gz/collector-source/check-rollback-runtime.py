#!/usr/bin/env python3
"""Two normal start/stop lifetimes after withdrawing the batch experiment."""
import hashlib
import importlib.util
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'build-output/pixel-batch-incremental-20261011'
spec = importlib.util.spec_from_file_location('quick', ROOT / 'tests/benchmark/pixel_quick.py')
quick = importlib.util.module_from_spec(spec)
spec.loader.exec_module(quick)
target = OUT / 'R0-recovery'
manifest = json.loads((target / 'preparation/manifest.json').read_text())
build = json.loads((target / 'build-manifest.json').read_text())
output = ROOT / 'build-output/vpp-admit-owner-long-20261011/rollback-runtime'
output.mkdir(exist_ok=False)
device = quick.Device(manifest['serial'], output)
device.helper = manifest['remote'] + '/socket-load'
result = {'status': 'RUNNING', 'profiles': [], 'errors': []}
active = False
try:
    assert device.state()['state'] == 'stopped'
    for profile in ('root', 'vpn'):
        active = True
        device.action('--ez', 'runtimeStart', 'true', '--es', 'runtimeProfile', profile)
        running = device.wait_state('running', profile)
        assert running['protectionRunning'] == 'true'
        cli = device.cli(profile, ['show threads', 'show product primary',
                                   'show product completion', 'show product root lanes',
                                   'show product tun'])
        (output / (profile + '-running-cli.txt')).write_text(cli)
        device.action('--ez', 'runtimeStop', 'true')
        stopped = device.wait_state('stopped')
        device.wait_process_gone('libvpp_runtime.so')
        if profile == 'root':
            log = device.command('shell', 'run-as', quick.PACKAGE, 'tail', '-n', '12',
                                 'files/product-state/s242-last-stop.log')
            (output / 'root-native-stop.txt').write_text(log)
            rows = quick.rows(log, 's242 event=stop_native_zero ')
            own = [row for row in rows if row.get('generation') == running['generation']]
            assert own and all(own[-1].get(k) == '0' for k in
                              ('ready_mask', 'graph_enabled', 'graph_accepting',
                               'pending', 'buffers', 'obligations', 'handoffs',
                               'completion_frames')), own
            residue = device.command('shell', 'run-as', quick.PACKAGE, 'cat',
                                     'files/product-state/s176-root-nfqueue-cleanup.properties')
            (output / 'root-residue.properties').write_text(residue)
            assert quick.properties(residue)['productRootNfqueueResidueClean'] == 'true'
        device.command('shell', 'am', 'force-stop', quick.PACKAGE)
        device.wait_process_gone(quick.PACKAGE + ':runtime')
        active = False
        result['profiles'].append({'profile': profile, 'running': running,
                                   'stopped': stopped})
    apk = device.command('shell', 'pm', 'path', quick.PACKAGE).strip().removeprefix('package:')
    hashes = device.root('sha256sum ' + quick.shlex.quote(apk) + ' ' +
                         quick.shlex.quote(manifest['rules_path']) + ' ' +
                         quick.shlex.quote(device.helper)).splitlines()
    assert hashes[0].split()[0] == build['apk_sha256']
    assert hashes[1].split()[0] == manifest['rules_sha256']
    assert hashes[2].split()[0] == manifest['android_sha256']
    assert int(device.command('shell', 'run-as', quick.PACKAGE, 'id', '-u').strip()) == manifest['uid']
    assert all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h
               for p, h in build['source_sha256'].items())
    result.update(status='PASS', apk_sha256=build['apk_sha256'],
                  rules_sha256=manifest['rules_sha256'], uid=manifest['uid'],
                  source_matches_build=True)
except BaseException as error:
    result['status'] = 'FAILED'
    result['errors'].append(str(error))
    raise
finally:
    if active:
        device.action('--ez', 'runtimeStop', 'true', cleanup=True)
        device.wait_state('stopped', cleanup=True)
        device.wait_process_gone('libvpp_runtime.so', cleanup=True)
        device.command('shell', 'am', 'force-stop', quick.PACKAGE, cleanup=True)
    result['final_runtime'] = device.state(cleanup=True)
    result['final_vpp_processes'] = device.command('shell', 'pidof', 'libvpp_runtime.so',
                                                 check=False, cleanup=True).strip()
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'profiles': len(result['profiles']),
                  'apk_sha256': result.get('apk_sha256'), 'errors': result['errors']}))
