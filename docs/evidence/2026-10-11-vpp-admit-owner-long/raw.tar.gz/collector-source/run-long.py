#!/usr/bin/env python3
"""Two reversed 30-second comparison pairs per ordinary Root/VPN lifetime."""
import importlib.util
import json
from pathlib import Path
import re
import shlex
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('quick', ROOT / 'tests/benchmark/pixel_quick.py')
quick = importlib.util.module_from_spec(spec)
spec.loader.exec_module(quick)
manifest = json.loads((OUT / 'preparation/manifest.json').read_text())
build = json.loads(Path(manifest['build_manifest']).read_text())
output = OUT / (sys.argv[1] if len(sys.argv) > 1 else 'run')
output.mkdir(exist_ok=False)
entry = time.monotonic()
device = quick.Device(manifest['serial'], output, entry + manifest['global_deadline_seconds'])
helper = manifest['remote'] + '/socket-load'
device.helper = helper
remote = manifest['remote'] + '/admit-long-' + str(time.time_ns())
commands = ['product admit-batch show', 'show product primary', 'show product completion',
            'show product root receive', 'show product root lanes', 'show product tun',
            'show product flow-stack', 'show product flows']
result = {'status': 'INCOMPLETE', 'manifest': manifest, 'protocol_sha256': quick.digest(OUT / 'pre-registered-long-protocol.json'),
          'runner_sha256': quick.digest(__file__), 'cases': [], 'lifetimes': [], 'errors': []}
active = False
samplers = {}
poller = None

def save(name, value):
    (output / name).write_text(json.dumps(value, indent=2) + '\n')

class PeerPoller:
    def __init__(self, case_id, cell):
        self.case_id, self.cell = case_id, cell
        self.stop = threading.Event()
        self.errors = []
        self.thread = threading.Thread(target=self.run, daemon=True)
    def run(self):
        with (self.cell / 'peer-samples.jsonl').open('w') as stream:
            while not self.stop.is_set():
                started = time.monotonic_ns()
                try:
                    value = quick.peer_query(manifest['peer_host'], manifest['peer_port'], self.case_id)
                    stream.write(json.dumps({'host_monotonic_ns': started, 'query_done_monotonic_ns': time.monotonic_ns(), 'peer': value}) + '\n')
                    stream.flush()
                except Exception as error:
                    self.errors.append(str(error))
                self.stop.wait(1)
    def finish(self):
        self.stop.set()
        self.thread.join(timeout=2)
        if self.thread.is_alive() or self.errors:
            raise RuntimeError('peer sampling failed: ' + str(self.errors))

def run_client(profile, case_id, ms, case='udp-fixed'):
    argv = [helper, 'client', manifest['peer_host'], str(manifest['peer_port']), str(case_id),
            case, str(ms), str(manifest['threads']), str(manifest['flows_per_thread'])]
    if case == 'udp-fixed': argv.extend([str(manifest['fixed_source_port_base']), str(manifest['fixed_source_port_stride'])])
    if profile == 'root': return device.command('shell', 'su', str(manifest['uid']), '-c', shlex.quote(shlex.join(argv)), timeout=ms / 1000 + 3)
    return device.command('shell', *argv, timeout=ms / 1000 + 3)

def select(profile, mode, cell):
    end = time.monotonic() + 3
    responses = []
    while time.monotonic() < end:
        value = device.cli(profile, ['product admit-batch ' + mode])
        responses.append(value)
        if 'admit.experiment mode=' + mode + ' ' in value:
            (cell / 'select-cli.txt').write_text('\n'.join(responses))
            return
        if 'mode change requires an empty graph' not in value: break
        time.sleep(.05)
    (cell / 'select-cli.txt').write_text('\n'.join(responses))
    raise RuntimeError('could not select mode on an empty graph')

def delta(before, after, prefix, field):
    total = lambda raw: sum(int(v.get(field, 0)) for v in quick.rows(raw, prefix))
    return total(after) - total(before)

def mechanism(before, after, client, cpu):
    fields = ['node_calls', 'node_vectors', 'node_clocks', 'primary_calls', 'primary_packets',
              'transferred', 'rejected', 'quads', 'scalars', 'external_frames']
    values = {k: delta(before, after, 'admit.experiment.thread ', k) for k in fields}
    values['physical_queue_publications'] = delta(before, after, 'admit.experiment.queue ', 'tail')
    values['graph_primary_rejected'] = delta(before, after, 'primary.status ', 'rejected')
    values['primary_remote_eligible'] = values['transferred'] + values['graph_primary_rejected']
    values['root_datagrams'] = delta(before, after, 'root.receive ', 'datagrams')
    values['root_unadmitted_accepts'] = delta(before, after, 'root.receive ', 'ingress_accepts')
    n, q = values['node_vectors'], values['physical_queue_publications']
    seconds = (client['end_monotonic_ns'] - client['start_monotonic_ns']) / 1e9
    values.update(vectors_per_call=n / values['node_calls'] if values['node_calls'] else None,
                  remote_packets_per_publication=values['transferred'] / q if q else None,
                  admit_clocks_per_vector=values['node_clocks'] / n if n else None,
                  vpp_cpu_seconds_per_admitted_packet=cpu['cpu_seconds'] * seconds / cpu['sample_coverage_seconds'] / n if n else None,
                  admitted_pps=n / seconds, remote_share=values['primary_remote_eligible'] / n if n else None,
                  root_bypass_share=values['root_unadmitted_accepts'] / values['root_datagrams'] if values['root_datagrams'] else None,
                  rejection_share=values['graph_primary_rejected'] / n if n else None)
    return values

def normal_stop(profile, running):
    device.action('--ez', 'runtimeStop', 'true', cleanup=True)
    stopped = device.wait_state('stopped', cleanup=True)
    device.wait_process_gone('libvpp_runtime.so', cleanup=True)
    device.command('shell', 'am', 'force-stop', quick.PACKAGE, cleanup=True)
    device.wait_process_gone(quick.PACKAGE + ':runtime', cleanup=True)
    audit = {'profile': profile, 'generation': running['generation'], 'stopped': stopped}
    if profile == 'root':
        tail = device.command('shell', 'run-as', quick.PACKAGE, 'tail', '-n', '12', 'files/product-state/s242-last-stop.log', cleanup=True)
        (output / 'root-native-stop.txt').write_text(tail)
        rows = quick.rows(tail, 's242 event=stop_native_zero ')
        assert len(rows) == 1 and rows[0]['generation'] == running['generation'], rows
        assert all(rows[0].get(k) == '0' for k in ('ready_mask', 'graph_enabled', 'graph_accepting', 'pending', 'buffers', 'obligations', 'handoffs', 'completion_frames')), rows
        residue = device.command('shell', 'run-as', quick.PACKAGE, 'cat', 'files/product-state/s176-root-nfqueue-cleanup.properties', cleanup=True)
        (output / 'root-residue.properties').write_text(residue)
        assert quick.properties(residue).get('productRootNfqueueResidueClean') == 'true'
        audit['native_zero'] = rows[0]
    result['lifetimes'].append(audit)

try:
    assert all(quick.digest(Path(manifest['source_snapshot']) / p) == h for p, h in build['source_sha256'].items())
    assert quick.digest(build['apk']) == manifest['apk_sha256']
    assert quick.digest(quick.SOURCE) == manifest['source_sha256']
    for field, path in [('android_sha256', 'android_binary'), ('host_sha256', 'host_binary')]:
        assert quick.digest(manifest[path]) == manifest[field]
    initial = device.state()
    save('initial-runtime.json', initial)
    assert initial.get('state') == 'stopped' and initial.get('mayBeActive') == 'false'
    assert not device.command('shell', 'pidof', 'libvpp_runtime.so', check=False).strip()
    hashes = device.root('sha256sum ' + shlex.join([manifest['apk'], manifest['rules_path'], helper])).splitlines()
    assert [v.split()[0] for v in hashes] == [manifest['apk_sha256'], manifest['rules_sha256'], manifest['android_sha256']]
    quick.peer_query(manifest['peer_host'], manifest['peer_port'], 0)
    device.root('mkdir ' + shlex.quote(remote))
    for profile in manifest['profile_order']:
        active = True
        (output / (profile + '-start.txt')).write_text(device.action('--ez', 'runtimeStart', 'true', '--es', 'runtimeProfile', profile))
        running = device.wait_state('running', profile)
        pids = device.command('shell', 'pidof', 'libvpp_runtime.so').strip().split()
        assert len(pids) == 1
        pid = int(pids[0])
        tcp_warm = run_client(profile, 14, 3000, 'tcp-fixed')
        (output / (profile + '-warm-tcp.json')).write_text(tcp_warm)
        assert json.loads(tcp_warm)['bytes'] > 0, 'TCP warmup received zero bytes before any measurement'
        for index, mode in enumerate(manifest['order']):
            if device.deadline - time.monotonic() < manifest['cell_ms'] / 1000 + 15:
                raise TimeoutError('insufficient budget for the complete next long window and cleanup')
            name = profile + '-' + str(index) + '-' + mode
            cell = output / name
            cell.mkdir()
            time.sleep(1)
            select(profile, mode, cell)
            quick.peer_query(manifest['peer_host'], manifest['peer_port'], 14, 'R')
            (cell / 'warm-udp.json').write_text(run_client(profile, 14, 1000))
            (cell / 'battery-before.txt').write_text(device.command('shell', 'dumpsys', 'battery'))
            before = device.cli(profile, ['show threads', *commands])
            (cell / 'before-cli.txt').write_text(before)
            assert 'unknown input' not in before.lower(), before[:1000]
            layout = [dict(id=int(m[1]), name=m[2], tid=int(m[3]), lcore=int(m[4]))
                      for m in (re.match(r'\s*(\d+)\s+(vpp_\S+)\s+(?:workers\s+)?(\d+)\s+\S+\s+\(\d+\)\s+(\d+)', line) for line in before.splitlines()) if m]
            assert len(layout) == 3 and [v['lcore'] for v in layout[1:]] == [1, 2], layout
            capacity = quick.rows(before, 'capacity.status ')
            assert len(capacity) == 1 and capacity[0]['credits'] == '32', capacity
            case_id = len(result['cases'])
            peer_before = quick.peer_query(manifest['peer_host'], manifest['peer_port'], case_id, 'R')
            host_before = time.monotonic()
            remote_cpu = remote + '/' + name + '.cpu.jsonl'
            sampler = device.root(shlex.join([helper, 'monitor', str(pid), str(manifest['cell_ms'] + 1250)]) + ' > ' + shlex.quote(remote_cpu) + ' 2>&1 < /dev/null & echo monitor=$!')
            samplers = quick.properties(sampler)
            assert samplers.get('monitor', '').isdigit(), sampler
            (cell / 'samplers.txt').write_text(sampler)
            poller = PeerPoller(case_id, cell)
            poller.thread.start()
            client_raw = run_client(profile, case_id, manifest['cell_ms'])
            poller.finish()
            poller = None
            (cell / 'client.json').write_text(client_raw)
            client = json.loads(client_raw)
            assert client['uid'] == (manifest['uid'] if profile == 'root' else 2000)
            assert client['fixed_source_port_base'] == manifest['fixed_source_port_base'] and client['fixed_source_port_stride'] == manifest['fixed_source_port_stride']
            seconds = (client['end_monotonic_ns'] - client['start_monotonic_ns']) / 1e9
            assert 29.9 <= seconds < 33, seconds
            after = device.cli(profile, commands)
            (cell / 'after-cli.txt').write_text(after)
            peer = quick.peer_query(manifest['peer_host'], manifest['peer_port'], case_id)
            peer['measurement_cpu_seconds'] = peer['peer_cpu_seconds'] - peer_before['peer_cpu_seconds']
            peer['measurement_wall_seconds'] = time.monotonic() - host_before
            peer['cpu_percent_one_core'] = peer['measurement_cpu_seconds'] / peer['measurement_wall_seconds'] * 100
            (cell / 'peer.json').write_text(json.dumps(peer, indent=2) + '\n')
            cpu_raw = device.root('cat ' + shlex.quote(remote_cpu))
            (cell / 'cpu.jsonl').write_text(cpu_raw)
            cpu = quick.monitor_summary(cpu_raw, client)
            assert cpu['sample_coverage_seconds'] > 29 and cpu['sample_count'] >= 140, cpu
            device.root('kill -TERM ' + samplers['monitor'] + ' 2>/dev/null || true')
            samplers = {}
            quick.validate_capture_window(profile, client, before, after)
            assert peer['udp_duplicates'] == peer['malformed'] == 0 and peer['underlay_unique_tuples'] == 64, peer
            assert peer['tuple_capacity_overflow_packets'] == peer['sequence_overflow_packets'] == 0, peer
            current = device.state()
            assert current['generation'] == running['generation'] and current['protectionRunning'] == 'true', current
            (cell / 'battery-after.txt').write_text(device.command('shell', 'dumpsys', 'battery'))
            values = mechanism(before, after, client, cpu)
            assert values['node_vectors'] > 0 and values['node_calls'] > 0 and .1 <= values['remote_share'] <= .9
            scores = quick.score(client, peer, cpu, after, before)
            result['cases'].append({'profile': profile, 'mode': mode, 'index': index, 'cell': name,
                                    'generation': running['generation'], 'pid': pid, 'client': client, 'peer': peer, 'cpu': cpu,
                                    'worker_layout': layout, 'capacity': capacity, 'mechanism': values, 'score': scores})
            save('result.json', result)
            print(name, json.dumps({'delivered_mbps': scores['delivered_mbps'], 'cpu_seconds_per_delivered_gib': scores['cpu_seconds_per_delivered_gib'],
                                    'admitted_pps': values['admitted_pps'], 'rejection_share': values['rejection_share'], 'root_bypass_share': values['root_bypass_share']}), flush=True)
        quiet = device.cli(profile, commands)
        (output / (profile + '-before-stop-cli.txt')).write_text(quiet)
        if profile == 'vpn':
            tun = quick.rows(quiet, 'tun.status ')
            assert len(tun) == 1 and all(tun[0].get(k) == '0' for k in ('pending', 'frames', 'buffers', 'obligations')), tun
            result['vpn_before_stop_native_zero'] = tun[0]
        normal_stop(profile, running)
        active = False
    result['status'] = 'COMPLETE'
except Exception as error:
    result['errors'].append(type(error).__name__ + ': ' + str(error))
finally:
    if poller:
        try: poller.finish()
        except Exception as error: result['errors'].append('peer sampling cleanup: ' + str(error))
    if samplers:
        try: device.root('kill -TERM ' + samplers['monitor'] + ' 2>/dev/null || true', cleanup=True)
        except Exception as error: result['errors'].append('sampler cleanup: ' + str(error))
    if active:
        try: normal_stop(profile, running)
        except Exception as error: result['errors'].append('cleanup: ' + str(error))
    try:
        result['final_runtime'] = device.state(cleanup=True)
        result['final_processes'] = device.command('shell', 'pidof', 'libvpp_runtime.so', check=False, cleanup=True).strip()
        result['rules_unchanged'] = device.root('sha256sum ' + shlex.quote(manifest['rules_path']), cleanup=True).split()[0] == manifest['rules_sha256']
        assert result['final_runtime'].get('state') == 'stopped' and result['final_runtime'].get('mayBeActive') == 'false' and not result['final_processes'] and result['rules_unchanged']
    except Exception as error: result['errors'].append('final audit: ' + str(error))
    result['elapsed_seconds'] = time.monotonic() - entry
    if result['elapsed_seconds'] > manifest['global_deadline_seconds'] or result['errors']: result['status'] = 'INCOMPLETE'
    save('result.json', result)
    print(json.dumps({'status': result['status'], 'elapsed_seconds': result['elapsed_seconds'], 'cases': len(result['cases']), 'errors': result['errors']}), flush=True)
sys.exit(result['status'] != 'COMPLETE')
