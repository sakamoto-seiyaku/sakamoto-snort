#!/usr/bin/env python3
import importlib.util
import json
from pathlib import Path
import subprocess
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
PREVIOUS = ROOT / 'build-output/vpp-admit-owner-batch-20261011'
spec = importlib.util.spec_from_file_location('quick', ROOT / 'tests/benchmark/pixel_quick.py')
quick = importlib.util.module_from_spec(spec)
spec.loader.exec_module(quick)
build = json.loads((PREVIOUS / 'instrumented/build-manifest.json').read_text())
old = json.loads((PREVIOUS / 'preparation-balanced/manifest.json').read_text())
assert subprocess.check_output(['git', 'diff', 'HEAD', '--', 'src/product/vpp'], cwd=ROOT) == b''
snapshot = PREVIOUS / 'instrumented/source'
assert all(quick.digest(snapshot / p) == h for p, h in build['source_sha256'].items())
assert quick.digest(build['apk']) == build['apk_sha256']
assert quick.digest(PREVIOUS / 'instrumented/symbols/libproduct_core_plugin.so') == build['unstripped_sha256']
prep = OUT / 'preparation'
quick.prepare(SimpleNamespace(output=prep, clang=quick.NDK_CLANG, serial=old['serial'],
                              peer=old['peer_host'], port=old['peer_port'], bind=old['peer_host'],
                              cell_ms=30000, no_profile=True))
manifest = json.loads((prep / 'manifest.json').read_text())
assert all(manifest[k] == old[k] for k in ('uid', 'rules_sha256', 'model'))
device = quick.Device(manifest['serial'], prep)
print(device.command('install', '-r', '-d', build['apk'], timeout=30).strip(), flush=True)
apk = device.command('shell', 'pm', 'path', quick.PACKAGE).strip().removeprefix('package:')
hashes = device.root('sha256sum ' + quick.shlex.join([apk, manifest['rules_path'], manifest['remote'] + '/socket-load'])).splitlines()
assert [v.split()[0] for v in hashes] == [build['apk_sha256'], manifest['rules_sha256'], manifest['android_sha256']]
assert int(device.command('shell', 'run-as', quick.PACKAGE, 'id', '-u').strip()) == manifest['uid']
manifest.update(apk=apk, apk_sha256=build['apk_sha256'], fixed_source_port_base=42000,
                fixed_source_port_stride=2, cell_ms=30000, global_deadline_seconds=600,
                order=['baseline', 'batch', 'batch', 'baseline'], profile_order=['root', 'vpn'],
                source_snapshot=str(snapshot), build_manifest=str(PREVIOUS / 'instrumented/build-manifest.json'),
                preparation_utc_ns=time.time_ns())
(prep / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(prep / 'socket_load.c').write_bytes(quick.SOURCE.read_bytes())
protocol = {'registered_utc_ns': time.time_ns(), 'purpose': 'User-requested longer throughput re-evaluation; keep the previous five-second evidence unchanged.',
            'native_apk_sha256': build['apk_sha256'], 'helper_sha256': manifest['android_sha256'],
            'cell_ms': 30000, 'windows_per_profile': 4, 'order': manifest['order'],
            'profiles': manifest['profile_order'], 'global_deadline_seconds': 600,
            'cohort': {'threads': 4, 'flows_per_thread': 16, 'udp_bytes': 1200, 'source_base': 42000, 'source_stride': 2, 'destination_base': 41320},
            'primary_outcomes': ['peer delivered Mbps', 'VPP CPU seconds per delivered unique GiB'],
            'secondary_outcomes': ['admission pps', 'admit clocks per vector', 'primary physical publications', 'rejection/bypass shares', 'per-second peer delivery', 'battery temperature', 'peer CPU headroom'],
            'interpretation': {'compare_both_reversed_pairs': True, 'aggregate_by_total_delivered_bytes_and_total_window_cpu': True,
                               'screening_positive': 'Both reversed pairs show >=5% delivery improvement and aggregate delivery improves >=10%, with aggregate VPP CPU/GiB falling >=5%; comparable remote share and no >3pp rejection/bypass regression.',
                               'other_profile': 'Report separately; no merged overall score. A single five-second gain or full CPU utilization is not a pass/fail conclusion.',
                               'limits': 'Two 30s windows per condition are screening evidence; not thermal steady state, statistical confidence or energy measurement.'},
            'correctness': ['same native APK/ELF/source snapshot and fixed tuple cohort', 'same rule/UID/W2/credits32 identity', 'same generation within each profile', 'capture progress and no duplicate/sequence overflow', 'ordinary zero-debt/residue cleanup']}
(OUT / 'pre-registered-long-protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
print(json.dumps({'prepared': str(prep / 'manifest.json'), 'apk_sha256': manifest['apk_sha256'], 'helper_sha256': manifest['android_sha256']}), flush=True)
